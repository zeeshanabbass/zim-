<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Header class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;


class Header extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_header_background_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_burger_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'xamin_action_btn_color_options'), 20);
	}

	public function xamin_header_background_style()
	{
		$xamin_option = get_option('xamin-options');
		$dynamic_css = '';

		if (isset($xamin_option['xamin_header_background_type'])) {
			if (isset($xamin_option['xamin_header_background_type']) && $xamin_option['xamin_header_background_type'] != 'default') {
				$type = $xamin_option['xamin_header_background_type'];
				if ($type == 'color') {
					if (!empty($xamin_option['xamin_header_background_color'])) {
						$dynamic_css = 'header#default-header{
							background : ' . $xamin_option['xamin_header_background_color'] . '!important;
						}';
					}
				}
				if ($type == 'image') {
					if (!empty($xamin_option['xamin_header_background_image']['url'])) {
						$dynamic_css = 'header#default-header{
							background : url(' . $xamin_option['xamin_header_background_image']['url'] . ') !important;
						}';
					}
				}
				if ($type == 'transparent') {
					$dynamic_css = 'header#default-header{
						background : transparent !important;
					}';
				}
			}
		}
		wp_add_inline_style('xamin-global', $dynamic_css);
	}

	public function xamin_menu_color_options()
	{

		$xamin_option =  get_option('xamin-options');
		$inline_css = '';

		if (!empty($xamin_option['menu_color']) && $xamin_option['menu_color'] == "custom") {

			if (isset($xamin_option['header_menu_color']) && !empty($xamin_option['header_menu_color'])) {
				$inline_css .= '.sf-menu > li > a{
						color : ' . $xamin_option['header_menu_color'] . '!important;
					}';
			}

			if (isset($xamin_option['hover_menu_color']) && !empty($xamin_option['hover_menu_color'])) {
				$inline_css .= '.sf-menu li:hover > a,.sf-menu li.current-menu-ancestor > a,.sf-menu  li.current-menu-item > a{
						color : ' . $xamin_option['hover_menu_color'] . ' !important;
					}';
			}
		}



		wp_add_inline_style('xamin-global', $inline_css);
	}

	public function xamin_sub_menu_color_options()
	{
		$xamin_option = get_option('xamin-options');
		$inline_css = '';
		if (isset($xamin_option['header_submenu_color_type']) && $xamin_option['header_submenu_color_type'] == 'custom') {
			if (isset($xamin_option['submenu_color']) && !empty($xamin_option['submenu_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu a{
                   		color : ' . $xamin_option['submenu_color'] . ' !important; }';
			}

			if (isset($xamin_option['hover_submenu_color']) && !empty($xamin_option['hover_submenu_color'])) {
				$inline_css .= '.sf-menu li.sfHover>a, .sf-menu li:hover>a,.sf-menu li.current-menu-ancestor>a, .sf-menu li.current-menu-item>a, .sf-menu ul>li.menu-item.current-menu-parent>a,.sf-menu ul li.current-menu-parent>a, .sf-menu ul li .sub-menu li.current-menu-item>a
                					{  color : ' . $xamin_option['hover_submenu_color'] . ' !important;  }';
			}

			if (isset($xamin_option['submenu_background_color']) && !empty($xamin_option['submenu_background_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu li{
                   background : ' . $xamin_option['submenu_background_color'] . ' !important;  }';
			}

			if (isset($xamin_option['hover_submenu_bg_color']) && !empty($xamin_option['hover_submenu_bg_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu li:hover,.sf-menu ul.sub-menu li.current-menu-item{
                   background : ' . $xamin_option['hover_submenu_bg_color'] . ' !important;   }';
			}
		}
		wp_add_inline_style('xamin-global', $inline_css);
	}

	public function xamin_burger_menu_color_options()
	{
		$xamin_option = get_option('xamin-options');
		$inline_css = '';

		if (isset($xamin_option['burger_menu_button_type']) && $xamin_option['burger_menu_button_type'] == 'custom') {

			if (isset($xamin_option['burger_menu_icon']) && !empty($xamin_option['burger_menu_icon'])) {
				$inline_css .= ' .menu-btn .line {
                    background-color : ' . $xamin_option['burger_menu_icon'] . ' !important;
                }';
			}

			if (isset($xamin_option['burger_menu_popup_bg']) && !empty($xamin_option['burger_menu_popup_bg'])) {
				$inline_css .= ' .xamin-mobile-menu {
                    background : ' . $xamin_option['burger_menu_popup_bg'] . ' !important;
                }';
			}
			

			if (isset($xamin_option['burger_menu_color']) && !empty($xamin_option['burger_menu_color'])) {
				$inline_css .= '.xamin-mobile-menu .navbar-nav > li > a, .xamin-mobile-menu .navbar-nav li > .toggledrop svg{ 
					color : ' . $xamin_option['burger_menu_color'] . ' !important;
				}';
			}


			if (isset($xamin_option['burger_hover_menu_color']) && !empty($xamin_option['burger_hover_menu_color'])) {
				$inline_css .= '.xamin-mobile-menu .navbar-nav li.current-menu-item > .toggledrop svg, .xamin-mobile-menu .navbar-nav li.current-menu-item > a, .xamin-mobile-menu .navbar-nav li .sub-menu li:hover > a, .xamin-mobile-menu .navbar-nav li:hover > .toggledrop svg, .xamin-mobile-menu .navbar-nav li:hover > a, .xamin-mobile-menu ul > li.current-menu-ancestor > .toggledrop svg, .xamin-mobile-menu ul > li.current-menu-ancestor > a, .xamin-mobile-menu ul li .sub-menu li.current-menu-item > a, .xamin-mobile-menu ul li .sub-menu li.menu-item.current-menu-ancestor > a{
			        color : ' . $xamin_option['burger_hover_menu_color'] . ' !important;
				}';
			}

			if (isset($xamin_option['burger_submenu_color']) && !empty($xamin_option['burger_submenu_color'])) {
				$inline_css .= '.xamin-mobile-menu .navbar-nav li .sub-menu li a , .xamin-mobile-menu .navbar-nav li .sub-menu li svg{
			        color : ' . $xamin_option['burger_submenu_color'] . ' !important;
				}';
			}
		}
		wp_add_inline_style('xamin-global', $inline_css);
	}

	public function xamin_action_btn_color_options()
	{
		$xamin_option = get_option('xamin-options');
		$inline_css = '';

		if (isset($xamin_option['button_color']) && $xamin_option['button_color'] == 'custom') {

			if (isset($xamin_option['button_bg_color']) && !empty($xamin_option['button_bg_color'])) {
				$inline_css .= '
            header .xamin-shop-btn-holder  #btn-search svg,header .search_count #btn-search{
                color : ' . $xamin_option['button_bg_color'] . ' !important;
            }';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('xamin-global', $inline_css);
		}
	}
}
