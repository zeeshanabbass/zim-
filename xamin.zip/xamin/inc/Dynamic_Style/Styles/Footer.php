<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Footer class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class Footer extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'xamin_footer_dynamic_style'), 20);
	}

	public function xamin_footer_dynamic_style()
	{

		$page_id = get_queried_object_id();
		$xamin_options = get_option('xamin-options');
		$footer_css = '';
		if (isset($xamin_options['footer_top'])) {

			if ($xamin_options['footer_top'] == 'no') {
				$footer_css = '.footer-top { 
					display : none !important;
				}';
			}
		}

		if (isset($xamin_options['change_footer_color'])) {

			if (isset($xamin_options['footer_bg_color']) && $xamin_options['change_footer_color'] == '0') {
				$footer_bg_color = $xamin_options['footer_bg_color'];
				$footer_css .= ".footer {
					background-color: $footer_bg_color !important;
				}";
			}
		}
	

		wp_add_inline_style('xamin-global', $footer_css);
	}
}
