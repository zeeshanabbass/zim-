<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\General class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class General extends Component
{
	public function __construct()
	{

		add_action('wp_enqueue_scripts', array($this, 'xamin_create_general_style'), 20);
	}

	public function xamin_create_general_style()
	{

		$xamin_option = get_option('xamin-options');
		$general_var = ':root { ';

		if (isset($xamin_option['grid_container']) && !empty($xamin_option['grid_container'])) {
			$general = $xamin_option['grid_container']['width'];
			$general_var .= ' --content-width: ' . $general . ' !important;';
		}
		$general_var .= '}';
		if (isset($xamin_option['body_set_option']) && $xamin_option['body_set_option'] == 1) {
			if (
				isset($xamin_option['body_color'])  && !empty($xamin_option['body_color'])
			) {
				$general = $xamin_option['body_color'];
				$general_var .= ' body { background : ' . $general . ' !important; }';
			}
		}
		if (isset($xamin_option['body_set_option']) && $xamin_option['body_set_option'] == 3) {
			if (isset($xamin_option['body_image']['url']) && !empty($xamin_option['body_image']['url'])) {
				$general = $xamin_option['body_image']['url'];
				$general_var .= '
					body { background-image: url(' . $general . ') !important; }';
			}
		}

		if (isset($xamin_option['back_to_top_btn']) && $xamin_option['back_to_top_btn'] == 'no') {
			if (isset($xamin_option['back_to_top_btn']) && !empty($xamin_option['back_to_top_btn'])) {
				$general_var .= '
					#back-to-top { display: none !important; }';
			}
		}

		wp_add_inline_style('xamin-global', $general_var);
	}
}
