<?php

/**
 * Xamin\Xamin\Dynamic_Style\Styles\Banner class
 *
 * @package xamin
 */

namespace Xamin\Xamin\Dynamic_Style\Styles;

use Xamin\Xamin\Dynamic_Style\Component;
use function add_action;

class Banner extends Component
{

    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'xamin_banner_dynamic_style'), 20);
        add_action('wp_enqueue_scripts', array($this, 'xamin_opacity_color'), 20);
        add_action('wp_enqueue_scripts', array($this, 'xamin_banner_hide'), 20);
    }

    public function xamin_banner_dynamic_style()
    {
        $page_id = get_queried_object_id();
        $xamin_options = get_option('xamin-options');
        $dynamic_css = '';

        if (isset($xamin_options['display_banner'])) {
            if ($xamin_options['display_banner'] == 'no') {
                $dynamic_css .=
                    '.xamin-breadcrumb-one { display: none !important; }
                    .content-area .site-main {padding : 0 !important; }';
            }
        }

        if (isset($xamin_options['display_title'])) {

            if ($xamin_options['display_title'] == 'no') {
                $dynamic_css .=
                    '.xamin-breadcrumb-one .title { display: none !important; }';
            }
        }

        if (isset($xamin_options['display_breadcumb'])) {

            if ($xamin_options['display_breadcumb'] == 'no') {
                $dynamic_css .=
                    '.xamin-breadcrumb-one .breadcrumb { display: none !important; }';
            }
        }

        if (isset($xamin_options['bg_title_color'])) {

            if ($xamin_options['bg_title_color'] == 'yes') {
                $dynamic = $xamin_options['bg_title_color'];
                $dynamic_css .=
                    '.xamin-breadcrumb-one .title { color: ' . $dynamic . ' !important; }';
            }
        }
        if (isset($xamin_options['bg_type'])) {
            $opt = $xamin_options['bg_type'];
            if ($opt == '1') {
                if (isset($xamin_options['bg_color']) && !empty($xamin_options['bg_color'])) {
                    $dynamic = $xamin_options['bg_color'];
                    $dynamic_css .=
                        '.xamin-breadcrumb-one { background: ' . $dynamic . ' !important; }';
                }
            }
            if ($opt == '2') {
                if (isset($xamin_options['banner_image']['url'])) {
                    $dynamic = $xamin_options['banner_image']['url'];
                    $dynamic_css .=
                        '.xamin-breadcrumb-one { background-image: url(' . $dynamic . ') !important; }';
                }
            }
        }

        wp_add_inline_style('xamin-global', $dynamic_css);
    }
    public function xamin_opacity_color()
    {
        //Set Background Opacity Color
        $xamin_options = get_option('xamin-options');

        if (!empty($xamin_options['bg_opacity']) && $xamin_options['bg_opacity'] == "3") {
            $bg_opacity = $xamin_options['opacity_color']['rgba'];
        }
        $dynamic_css = '';

        if (!empty($xamin_options['bg_opacity']) && $xamin_options['bg_opacity'] == "3") {
            if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
                $dynamic_css .= "
            .breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
                background : $bg_opacity !important;
            }";
            }
        }
        wp_add_inline_style('xamin-global', $dynamic_css);
    }

    public function xamin_banner_hide()
    { 
        $xamin_options = get_option('xamin-options');
        $banner_hide = '';
        $pages = '';
        if(isset($xamin_options['pages_select'])){
            $pages = $xamin_options['pages_select'];
            foreach($pages as $data){

                $page = get_page_by_path( $data );
                if(isset($page)){
                    $banner_hide .= '.page-id-'.$page->ID.' .xamin-breadcrumb-one { display: none !important; }';
                }
    
            }
        }

        wp_add_inline_style('xamin-global', $banner_hide);
    }

}
