<?php
/**
 * Template part for displaying a post's comment and edit links
 *
 * @package xamin
 */

namespace Xamin\Xamin;

?>
<div class="entry-actions">
	<?php xamin()->xamin_get_blog_readmore_link(get_the_permalink(), 'Read More'); ?>
</div><!-- .entry-actions -->
