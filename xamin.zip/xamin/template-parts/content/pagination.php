<?php
/**
 * Template part for displaying a pagination
 *
 * @package xamin
 */

namespace Xamin\Xamin;

xamin()->xamin_pagination();
