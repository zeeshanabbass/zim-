<?php

/**
 * Template part for displaying the footer info
 *
 * @package xamin
 */

namespace Xamin\Xamin;

if (class_exists('ReduxFramework')) {

	$xamin_options = get_option('xamin-options');
?>
	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<?php if (isset($xamin_options['display_copyright']) && $xamin_options['display_copyright'] == 'yes') {  ?>
					<div class="col-sm-12 m-0 text-<?php echo esc_attr($xamin_options['footer_copyright_align']); ?>">
						<div class="pt-3 pb-3">
							<?php
							if (isset($xamin_options['footer_copyright'])) {  ?>
								<span class="copyright"><?php echo html_entity_decode($xamin_options['footer_copyright']); ?></span>
							<?php
							} else {	?>
								<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://iqonic.design/', 'xamin')); ?>"> <?php printf(esc_html__('© 2022', 'xamin'), 'xamin'); ?><strong><?php printf(esc_html__(' xamin ', 'xamin'), 'xamin'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'xamin'), 'xamin'); ?></a></span>
							<?php
							} ?>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div><!-- .site-info -->

<?php } else { ?>

	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="pt-3 pb-3">
						<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://iqonic.design/', 'xamin')); ?>"> <?php printf(esc_html__('© 2022', 'xamin'), 'xamin'); ?><strong><?php printf(esc_html__(' xamin ', 'xamin'), 'xamin'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'xamin'), 'xamin'); ?></a></span>
					</div>
				</div>
			</div>
		</div>
	</div><!-- .site-info -->
<?php }
