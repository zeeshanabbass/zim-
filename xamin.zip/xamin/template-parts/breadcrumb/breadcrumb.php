<?php

/**
 * Template part for displaying the Breadcrumb 
 *
 * @package xamin
 */

namespace Xamin\Xamin;

if (is_front_page()) {
        if (is_home()) { ?>
            <div class="xamin-breadcrumb-one text-center green-bg">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-sm-12">
                            <div class="heading-title white xamin-breadcrumb-title">
                                <h1 class="title"><?php esc_html_e('Home', 'xamin'); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php }
}
xamin()->xamin_inner_breadcrumb();
?>